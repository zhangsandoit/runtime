//
//  main.m
//  zhcTest
//
//  Created by cocoa on 2020/6/12.
//

#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
           
           NSLog(@"Hello, World!");
       }
       return 0;
    
}
